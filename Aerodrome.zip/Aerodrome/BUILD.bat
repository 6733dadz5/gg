@echo off
cd /d "%~dp0"
echo === Aerodrome build ===
where node >nul 2>nul || (echo Install Node.js first: https://nodejs.org & pause & exit /b 1)
call npm install || goto :fail
call node scripts\vendor.js || goto :fail
call npm run dist || goto :fail
echo.
echo Done. Your game is in: dist\win-unpacked\Aerodrome.exe
echo Copy the whole win-unpacked folder to share it.
pause & exit /b 0
:fail
echo Build failed. Check your internet connection and try again.
pause
