AERODROME - how to get the .exe

1. Install Node.js (LTS) from https://nodejs.org  (one time).
2. Double-click BUILD.bat. It needs internet once.
3. Open dist\win-unpacked\ . Aerodrome.exe is inside. Keep the whole folder together.

F11 toggles fullscreen. To test without building: npm install, then npm start.
